import requests
import time
import os
import shutil

def clear()
    os.system('cls' if os.name == 'nt' else 'clear')

def center(text)
    width = shutil.get_terminal_size().columns
    return text.center(width)

def header()
    clear()
    print(033[94m)
    print(center(╔══════════════════════════════════════════════════════╗))
    print(center(║                 IP LOOKUP OSINT MODE                 ║))
    print(center(╚══════════════════════════════════════════════════════╝))
    print(033[0mn)

def main()
    header()
    ip = input(🔢 Inserisci l'indirizzo IP da analizzare ).strip()

    try
        headers = {User-Agent BoosterTool1.0}
        response = requests.get(fhttpsipinfo.io{ip}json, headers=headers, timeout=5)
        data = response.json()

        loc = data.get(loc, NA)
        maps_link = fhttpswww.google.commapsplace{loc} if loc != NA else NA

        print(n════════════════════════════════════════════════════════════)
        print(fIP {data.get('ip', ip)})
        print(fLocation {data.get('city', 'Unknown')}, {data.get('region', 'Unknown')}, {data.get('country', 'Unknown')})
        print(fISPOrg {data.get('org', 'Unknown')})
        print(fCoordinates {loc})
        print(f🌍 Google Maps {maps_link})
        print(════════════════════════════════════════════════════════════)
    except Exception as e
        print(❌ Errore durante il recupero dell'IP.)
        print(fDettagli {e})
    input(nPremi Invio per chiudere...)

if __name__ == __main__
    main()
