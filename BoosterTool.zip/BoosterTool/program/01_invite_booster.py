import time
import random
import os
import shutil

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

def center(text):
    width = shutil.get_terminal_size().columns
    return text.center(width)

def header():
    clear()
    print("\033[96m")
    print(center("╔══════════════════════════════════════════════════════╗"))
    print(center("║              DISCORD INVITE BOOSTER v1.0             ║"))
    print(center("╚══════════════════════════════════════════════════════╝"))
    print("\033[0m\n")

def main():
    header()
    invite = input("🔗 Invite: ").strip()
    print(f"\n🔗 Collegamento ricevuto: {invite}")
    time.sleep(0.5)

    print("\n👥 Joining users...")
    time.sleep(1)

    base_names = [
        "Shadow", "Pixel", "Nova", "Luna", "Ghost", "Neo", "Crimson", "Echo",
        "Sky", "Dark", "Frost", "Cyber", "Venom", "Star", "Iron", "Void",
        "Flare", "Claw", "Byte", "Blade", "Spark", "Knight", "Pulse", "Wolf"
    ]
    usernames = []
    for _ in range(1000):
        name = random.choice(base_names) + random.choice(base_names)
        tag = str(random.randint(1000, 9999))
        usernames.append(f"{name}#{tag}")

    for i in range(5):
        user = random.choice(usernames)
        print(f"🚀 Boosting server... User: {user}")
        time.sleep(0.6)

    print("\n✅ Inviti simulati completati.")
    input("\nPremi Invio per chiudere...")

if __name__ == "__main__":
    main()
