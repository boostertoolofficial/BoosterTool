import time
import random
import webbrowser
import os
import shutil

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

def center(text):
    width = shutil.get_terminal_size().columns
    return text.center(width)

def header():
    clear()
    print("\033[95m")
    print(center("╔══════════════════════════════════════════════════════╗"))
    print(center("║             DISCORD NITRO GENERATOR v1.0             ║"))
    print(center("╚══════════════════════════════════════════════════════╝"))
    print("\033[0m\n")

def main():
    header()
    print("🎁 Generatore di codici Discord Nitro")
    try:
        count = int(input("🔢 Quanti codici vuoi generare? > "))
        print("\n🎉 Codici generati:")
        codes = []
        for _ in range(count):
            code = ''.join(random.choices('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789', k=16))
            url = f"https://discord.gift/{code}"
            codes.append(url)
            print(url)

        open_all = input("\n🌐 Vuoi aprire tutte le schede nel browser? (s/n) > ").strip().lower()
        if open_all == "s":
            print("\n🚀 Apertura schede in corso...")
            for url in codes:
                webbrowser.open_new_tab(url)
                time.sleep(0.3)

        print("\n✅ Generazione completata.")
    except ValueError:
        print("❌ Inserisci un numero valido.")
    input("\nPremi Invio per chiudere...")

if __name__ == "__main__":
    main()
