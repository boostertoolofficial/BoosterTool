import time
import os

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

def center(text):
    width = shutil.get_terminal_size().columns
    return text.center(width)

def header():
    clear()
    print("\033[91m")
    print(center("╔══════════════════════════════════════════════════════╗"))
    print(center("║                    D0X MANUALE MODE                  ║"))
    print(center("╚══════════════════════════════════════════════════════╝"))
    print("\033[0m\n")

def main():
    header()
    print("📁 d0x manuale in sviluppo...")
    input("\nPremi Invio per chiudere...")

if __name__ == "__main__":
    main()
