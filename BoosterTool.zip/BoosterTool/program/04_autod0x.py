import os
import time
import shutil

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

def center(text):
    width = shutil.get_terminal_size().columns
    return text.center(width)

def header():
    clear()
    print("\033[93m")
    print(center("╔══════════════════════════════════════════════════════╗"))
    print(center("║                   AUTOD0X GENERATOR                  ║"))
    print(center("╚══════════════════════════════════════════════════════╝"))
    print("\033[0m\n")

def main():
    header()
    print("🧠 Autod0x in corso...")
    time.sleep(1)

    folder = "files"
    os.makedirs(folder, exist_ok=True)

    filename = os.path.join(folder, "AutoDox (Run Me!).bat")
    bat_script = """@echo off
setlocal
set LOGFILE=%~dp0privacy_audit_%COMPUTERNAME%_%DATE:~6,4%-%DATE:~3,2%-%DATE:~0,2%.txt
echo ===== Privacy audit - %DATE% %TIME% ===== > "%LOGFILE%"
echo Hostname: %COMPUTERNAME% >> "%LOGFILE%"
echo User: %USERNAME% >> "%LOGFILE%"
echo. >> "%LOGFILE%"
echo --- IP configuration --- >> "%LOGFILE%"
ipconfig /all >> "%LOGFILE%" 2>&1
echo. >> "%LOGFILE%"
echo --- Network connections (listening) --- >> "%LOGFILE%"
netstat -an | find "LISTEN" >> "%LOGFILE%" 2>&1
echo. >> "%LOGFILE%"
echo --- Account info --- >> "%LOGFILE%"
whoami /all >> "%LOGFILE%" 2>&1
echo. >> "%LOGFILE%"
echo --- System info --- >> "%LOGFILE%"
systeminfo >> "%LOGFILE%" 2>&1
echo. >> "%LOGFILE%"
echo Audit completato. Log salvato in: %LOGFILE%
pause
endlocal
"""
    with open(filename, "w", encoding="utf-8") as f:
        f.write(bat_script)

    print("✅ Autod0x salvato nella cartella 'files' come 'AutoDox (Run Me!).bat'")
    input("\nPremi Invio per chiudere...")

if __name__ == "__main__":
    main()
